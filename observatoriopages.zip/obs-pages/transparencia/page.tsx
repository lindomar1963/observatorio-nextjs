import Nav from '@/components/Nav'
import Footer from '@/components/Footer'
import Link from 'next/link'

export const metadata = {
  title: 'Transparência — Observatório de Segurança Pública do Amazonas',
}

const ITENS = [
  { titulo: 'Resolução de criação — ALEAM nº 003/2023', tipo: 'Documento legal', status: 'Disponível' },
  { titulo: 'Relatório de atividades 2024', tipo: 'Relatório institucional', status: 'Disponível' },
  { titulo: 'Relatório de atividades 2025', tipo: 'Relatório institucional', status: 'Em elaboração' },
  { titulo: 'Orçamento e execução financeira 2025', tipo: 'Financeiro', status: 'Portal ALEAM' },
  { titulo: 'Contratos e convênios vigentes', tipo: 'Contratações', status: 'Portal ALEAM' },
  { titulo: 'Plano de trabalho 2026', tipo: 'Planejamento', status: 'Em elaboração' },
  { titulo: 'Protocolo de cooperação — UFAM', tipo: 'Parceria', status: 'Disponível' },
  { titulo: 'Protocolo de cooperação — SSP-AM', tipo: 'Parceria', status: 'Disponível' },
]

const statusColor: Record<string, string> = {
  'Disponível': 'text-green-400',
  'Em elaboração': 'text-yellow-400',
  'Portal ALEAM': 'text-blue-400',
}

export default function TransparenciaPage() {
  return (
    <main>
      <Nav />
      <section className="bg-obs-navy px-4 md:px-8 py-16">
        <div className="max-w-4xl mx-auto">
          <p className="text-obs-gold text-xs font-bold tracking-widest uppercase mb-4">Prestação de contas</p>
          <h1 className="font-display text-3xl md:text-4xl font-bold text-white mb-4">Transparência</h1>
          <p className="text-white/60 text-sm max-w-xl">
            Documentos, relatórios institucionais, contratos e informações de acesso público
            do Observatório de Segurança Pública do Amazonas, em cumprimento à Lei nº 12.527/2011.
          </p>
        </div>
      </section>
      <section className="bg-gradient-to-b from-obs-navy to-[#0F2A45] px-4 md:px-8 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="space-y-3">
            {ITENS.map((item, i) => (
              <div key={i} className="flex flex-col md:flex-row md:items-center gap-2 border border-white/10 bg-white/5 p-4">
                <div className="flex-1">
                  <p className="text-white/85 text-sm font-medium">{item.titulo}</p>
                  <p className="text-white/35 text-xs">{item.tipo}</p>
                </div>
                <span className={`text-xs font-bold flex-shrink-0 ${statusColor[item.status] || 'text-white/40'}`}>
                  {item.status}
                </span>
              </div>
            ))}
          </div>
          <p className="text-white/30 text-xs mt-8">
            Documentos marcados como &quot;Portal ALEAM&quot; estão disponíveis no portal oficial da Assembleia Legislativa do Estado do Amazonas.
          </p>
        </div>
      </section>
      <section className="bg-obs-navy px-4 md:px-8 py-10 border-t border-white/10">
        <div className="max-w-4xl mx-auto flex flex-wrap gap-3">
          <a href="https://www.aleam.am.leg.br" target="_blank" rel="noopener noreferrer" className="bg-obs-gold text-obs-navy font-bold text-sm px-6 py-3 hover:bg-yellow-500 transition-colors">Portal ALEAM →</a>
          <Link href="/contato" className="border border-white/30 text-white font-semibold text-sm px-6 py-3 hover:border-white/60 transition-colors">Solicitar informação</Link>
        </div>
      </section>
      <Footer />
    </main>
  )
}
